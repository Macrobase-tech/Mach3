Copy all files in this directory (including subdirectories) to the MACH3 installation directory (for example: D:\Mach3).

This is set for the interface board (BL-UsbMach) and can be immediately used.
(Note: The driver in this setting adopts the wiring method of common anode)